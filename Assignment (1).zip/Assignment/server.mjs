import express from 'express';
import axios from 'axios';
import path from 'path';
import { fileURLToPath } from 'url';

const app = express();
const port = 3000;

const client_id = '84e5d97d716441bbb4b25833d806b248';
const client_secret = 'c0f8225734d64c93b909297b6c98d89e';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
app.use(express.static(path.join(__dirname, 'public')));

async function getaccesstoken() {
    const auth = `Basic ${Buffer.from(`${client_id}:${client_secret}`).toString('base64')}`;
    const response = await axios.post('https://accounts.spotify.com/api/token', `grant_type=client_credentials`, {
        headers: {
            'Authorization': auth,
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    });
    return response.data.access_token;
}

async function get(url, config) {
    return axios.get(url, config);
}

app.get('/api/music', async (req, res) => {
    try {
        const token = await getaccesstoken();
        const response = await get('https://api.spotify.com/v1/search', {
            headers: {
                'Authorization': `Bearer ${token}`
            },
            params: {
                q: 'year:2023 genre:bollywood',
                market: 'IN',
                type: 'track',
                limit: 50
            }
        });

        res.json(response.data.tracks.items);
    } catch (error) {
        res.status(500).send(error.message);
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
